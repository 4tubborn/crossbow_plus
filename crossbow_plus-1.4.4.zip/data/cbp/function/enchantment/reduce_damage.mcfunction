return fail

schedule function cbp:enchantment/reduce_damage2 1t